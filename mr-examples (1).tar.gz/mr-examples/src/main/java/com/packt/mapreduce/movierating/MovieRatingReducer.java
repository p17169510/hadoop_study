package com.packt.mapreduce.movierating;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;

public class MovieRatingReducer extends Reducer<DoubleWritable, Text, DoubleWritable, Text> {
    private int K = 20;
    private TreeMap<Double, String> topMiviesByRating = new TreeMap<>();

    @Override
    protected void reduce(DoubleWritable key, Iterable<Text> values, Context context)
            throws IOException, InterruptedException {
        for (Text movie : values) {
            topMiviesByRating.put(key.get(), movie.toString());
            if (topMiviesByRating.size() > K) {
                topMiviesByRating.remove(topMiviesByRating.firstKey());
            }
        }
    }

    @Override
    protected void cleanup(Context context) throws IOException,
            InterruptedException {
        for (Map.Entry<Double, String> movieDetail: topMiviesByRating.entrySet()) {
            context.write(new DoubleWritable(movieDetail.getKey()),
                new Text(movieDetail.getValue()));
        }
    }


}
